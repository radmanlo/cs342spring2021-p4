Turan Mert Duran 21601418
Radman Lotfiazar 21600450





